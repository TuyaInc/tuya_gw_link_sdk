﻿/*!
\file tuya_iot_route_api.h
Copyright(C),2017
*/

#ifndef _TUYA_IOT_ROUTE_API_H
#define _TUYA_IOT_ROUTE_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_iot_com_api.h"

/***********************************************************
*************************micro define***********************
***********************************************************/

#define ACCESS_TOKEN_LEN_MAX       256

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

/***********************************************************
*  Function: tuya_iot_route_start
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_route_init(VOID);

OPERATE_RET tuya_iot_route_start(VOID);

OPERATE_RET tuya_iot_route_stop(VOID);

/***********************************************************
*  Function: dev_get_access_token
*  Input: 
#        token: token buffer
#        size: token buffer size
*  Output: token
*  Return: OPERATE_RET 
***********************************************************/
OPERATE_RET dev_get_access_token(CHAR_T *token, INT_T size);


#ifdef __cplusplus
}
#endif

#endif  /*_TUYA_IOT_API_H*/

