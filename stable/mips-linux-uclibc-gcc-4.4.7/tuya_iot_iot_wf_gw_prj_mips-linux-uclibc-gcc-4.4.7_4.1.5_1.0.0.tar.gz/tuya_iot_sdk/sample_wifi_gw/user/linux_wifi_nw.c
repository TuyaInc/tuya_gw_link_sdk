/***********************************************************
*  File: linux_base_nw.c
*  Author: nzy
*  Date: 20171213
***********************************************************/
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <unistd.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>
#include "wifi_hwl.h"
#include "uni_log.h"

/***********************************************************
*************************micro define***********************
***********************************************************/
// 实际对应的端口名称
#define NET_DEV "wlan0" 

/***********************************************************
*************************function define********************
***********************************************************/
OPERATE_RET hwl_wf_all_ap_scan(OUT AP_IF_S **ap_ary,OUT UINT_T *num)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_assign_ap_scan(IN CONST CHAR_T *ssid,OUT AP_IF_S **ap)
{

    return OPRT_OK;

}

OPERATE_RET hwl_wf_release_ap(IN AP_IF_S *ap)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_set_cur_channel(IN CONST BYTE_T chan)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_get_cur_channel(OUT BYTE_T *chan)
{
    return OPRT_OK;
}

OPERATE_RET hwl_wf_sniffer_set(IN CONST BOOL_T en,IN CONST SNIFFER_CALLBACK cb)
{
    return OPRT_OK;
}

OPERATE_RET hwl_wf_get_ip(IN CONST WF_IF_E wf,OUT NW_IP_S *ip)
{
    int sock;
    char ipaddr[50];

    struct   sockaddr_in *sin;
    struct   ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
         PR_ERR("socket create failse...GetLocalIp!");
         return OPRT_COM_ERROR;
    }

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, NET_DEV, sizeof(ifr.ifr_name) - 1);

    if( ioctl( sock, SIOCGIFADDR, &ifr) < 0 ) {
         PR_ERR("ioctl error");
         close(sock);
         return OPRT_COM_ERROR;
    }

    sin = (struct sockaddr_in *)&ifr.ifr_addr;
    strcpy(ip->ip,inet_ntoa(sin->sin_addr)); 
    close(sock);

    return OPRT_OK;
}

OPERATE_RET hwl_wf_get_mac(IN CONST WF_IF_E wf,INOUT NW_MAC_S *mac)
{
    int sock;
    struct   sockaddr_in *sin;
    struct   ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
         PR_ERR("socket create failse...GetLocalIp!");
         return OPRT_COM_ERROR;
    }

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, NET_DEV, sizeof(ifr.ifr_name) - 1);

    if(ioctl(sock,SIOCGIFHWADDR,&ifr) < 0) {
        PR_ERR("ioctl error errno");
        close(sock);
        return FALSE;
    }
    memcpy(mac->mac,ifr.ifr_hwaddr.sa_data,sizeof(mac->mac));

    PR_DEBUG("WIFI Get MAC %02X-%02X-%02X-%02X-%02X-%02X\r\n",
             mac->mac[0],mac->mac[1],mac->mac[2],mac->mac[3],mac->mac[4],mac->mac[5]);
    close(sock);

    return OPRT_OK;
}


OPERATE_RET hwl_wf_set_mac(IN CONST WF_IF_E wf,IN CONST NW_MAC_S *mac)
{
    return OPRT_COM_ERROR;
}

OPERATE_RET hwl_wf_wk_mode_set(IN CONST WF_WK_MD_E mode)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_wk_mode_get(OUT WF_WK_MD_E *mode)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_station_connect(IN CONST CHAR_T *ssid,IN CONST CHAR_T *passwd)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_station_disconnect(VOID)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_station_get_conn_ap_rssi(OUT SCHAR_T *rssi)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_station_stat_get(OUT WF_STATION_STAT_E *stat)
{

    return OPRT_OK;
}

OPERATE_RET hwl_wf_ap_start(IN CONST WF_AP_CFG_IF_S *cfg)
{
    return OPRT_OK;
}

OPERATE_RET hwl_wf_ap_stop(VOID)
{
    return OPRT_OK;
}

OPERATE_RET hwl_wf_set_country_code(IN CONST CHAR_T *p_country_code)
{
    PR_DEBUG("Country Code:%s", p_country_code);
    return OPRT_OK;
}

OPERATE_RET hwl_wf_station_get_ap_mac(INOUT NW_MAC_S *mac)
{
    return OPRT_OK;
}

OPERATE_RET hwl_lowpower_enable(VOID)
{
    return OPRT_OK;
}

OPERATE_RET hwl_lowpower_disable(VOID)
{
    return OPRT_OK;
}


