/***********************************************************
*  File: linux_base_nw.c
*  Author: nzy
*  Date: 20171213
***********************************************************/
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <unistd.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/sockios.h>

#include <pthread.h>
#include "base_nw_intf.h"
#include "uni_log.h"


/***********************************************************
*************************micro define***********************
***********************************************************/
// 实际对应的端口名称
#define NET_DEV "eth0" 
#define default_wired_ip "192.168.1.254"

/***********************************************************
*************************function define********************
***********************************************************/
STATIC OPERATE_RET hwl_bnw_get_inter_updown_status(BOOL_T *is_up);

// 获取对应端口的ip地址
CHAR_T g_wired_net_name[16] = {0};
OPERATE_RET hwl_bnw_set_net_interface_name(IN CONST CHAR_T *wired_net_name)
{
    if(wired_net_name)
        snprintf(g_wired_net_name, 16, "%s", wired_net_name);
}

// 获取对应端口的ip地址
OPERATE_RET hwl_bnw_get_ip(OUT NW_IP_S *ip)
{
    int sock;
    char ipaddr[50];

    struct   sockaddr_in *sin;
    struct   ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
         PR_ERR("socket create failse...GetLocalIp!");
         return OPRT_COM_ERROR;
    }

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, g_wired_net_name, sizeof(ifr.ifr_name) - 1);

    if( ioctl( sock, SIOCGIFADDR, &ifr) < 0 ) {
         PR_ERR("wired:%s ioctl error", g_wired_net_name);
         PR_ERR("ioctl,errno:%d",unw_get_errno());
         close(sock);
         return OPRT_COM_ERROR;
    }

    sin = (struct sockaddr_in *)&ifr.ifr_addr;
    strcpy(ip->ip,inet_ntoa(sin->sin_addr)); 
    close(sock);

    return OPRT_OK;
}

// 获取对应端口的连接状况
BOOL_T hwl_bnw_station_conn(VOID)
{
#if 0
    int sock;
    struct   sockaddr_in *sin;
    struct   ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
         PR_ERR("socket create failse...GetLocalIp!");
         return OPRT_COM_ERROR;
    }

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, g_wired_net_name, sizeof(ifr.ifr_name) - 1);

    if(ioctl(sock,SIOCGIFFLAGS,&ifr) < 0) {
        PR_ERR("ioctl error");
        close(sock);
        return FALSE;
    }
    close(sock);

    if(0 == (ifr.ifr_flags & IFF_UP)) { 
        return FALSE;
    }  

    return TRUE;
#else
    OPERATE_RET op_ret = OPRT_OK;
    BOOL_T is_up = FALSE;
    op_ret = hwl_bnw_get_inter_updown_status(&is_up);

    return is_up;

#endif
}

// 若网关为wifi+有线模式,需要用户自己实现wifi连接的函数，配网时app会将指定路由的ssid、passwd传下来
// sdk会自动调用
OPERATE_RET hwl_bnw_set_station_connect(IN CONST CHAR_T *ssid,IN CONST CHAR_T *passwd)
{
    return OPRT_COM_ERROR;
}

// 若网关为wifi+有线模式，返回true，此时app会调用“hwl_bnw_set_station_connect”，将指定路由的ssid、passwd传下来
BOOL_T hwl_bnw_need_wifi_cfg(VOID)
{
    return FALSE;
}

// 若网关为wifi+有线模式，接口返回wifi与路由器的实际的连接信号值，需用户自己实现
OPERATE_RET hwl_bnw_station_get_conn_ap_rssi(OUT SCHAR_T *rssi)
{
    *rssi = 99;

    return OPRT_OK;
}

// 获取设备mac
OPERATE_RET hwl_bnw_get_mac(OUT NW_MAC_S *mac)
{
    int sock;
    struct   sockaddr_in *sin;
    struct   ifreq ifr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
         PR_ERR("socket create failse...GetLocalIp!");
         return OPRT_COM_ERROR;
    }

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, g_wired_net_name, sizeof(ifr.ifr_name) - 1);

    if(ioctl(sock,SIOCGIFHWADDR,&ifr) < 0) {
        PR_ERR("ioctl error errno");
        close(sock);
        return FALSE;
    }
    memcpy(mac->mac,ifr.ifr_hwaddr.sa_data,sizeof(mac->mac));

    PR_DEBUG("WIFI Get MAC %02X-%02X-%02X-%02X-%02X-%02X\r\n",
             mac->mac[0],mac->mac[1],mac->mac[2],mac->mac[3],mac->mac[4],mac->mac[5]);
    close(sock);

    return OPRT_OK;
}

// 无需实现
OPERATE_RET hwl_bnw_set_mac(IN CONST NW_MAC_S *mac)
{
    if(NULL == mac) {
        return OPRT_INVALID_PARM;
    }
    PR_DEBUG("WIFI Set MAC\r\n");

    return OPRT_OK;
}
 
#define ETHTOOL_GLINK        0x0000000a /* Get link status (ethtool_value) */
struct ethtool_value
{
    UINT_T    cmd;
    UINT_T    data;
};
 
STATIC OPERATE_RET hwl_bnw_get_inter_updown_status(BOOL_T *is_up)
{
    INT_T fd;
    struct ifreq ifr;
    struct ethtool_value edata;
   
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, g_wired_net_name, sizeof(ifr.ifr_name)-1);
    
    if((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
        perror("socket ");
        PR_ERR("socket error.");
        return OPRT_SOCK_ERR;
    }

    edata.cmd = ETHTOOL_GLINK;
    ifr.ifr_data = (caddr_t) &edata;
    if (ioctl(fd, SIOCETHTOOL, &ifr) == -1)
    {
        perror("ETHTOOL_GLINK failed ");
        PR_ERR("ioctl error.");
        close(fd);
        return OPRT_COM_ERROR;
    }
    close(fd);

    if(edata.data)
        *is_up = TRUE;
    else
        *is_up = FALSE;
        
    return OPRT_OK;
}

// 获取有线的IP地址
STATIC OPERATE_RET wired_inf_get_ip(IN CHAR_T *inf_name,OUT NW_IP_S *ip)
{
    if(inf_name == NULL)
        return OPRT_COM_ERROR;

    char tmpCmd[100] = {0};
    snprintf(tmpCmd, 100, "ifconfig %s",inf_name);

    FILE *pp = popen(tmpCmd, "r");
    if(pp == NULL)
        return OPRT_COM_ERROR;
    
    char tmp[256];
    memset(tmp, 0, sizeof(tmp));
    while (fgets(tmp, sizeof(tmp), pp) != NULL)
    {
        char *pIPStart = strstr(tmp, "inet ");
        if(pIPStart != NULL)
        {/* 目前都是一行里面包含ip gw mask 直接跳出  */
            break;
        }
    }

    /* 查找ip  */
    char *pIPStart = strstr(tmp, "inet addr:");
    if(pIPStart != NULL)
        sscanf(pIPStart + strlen("inet addr:"), "%s", ip->ip);
    else {
        fclose(pp);
        return OPRT_COM_ERROR;
    }
    /* 查找gw  */
    char *pGWStart = strstr(tmp, "broadcast ");
    if(pGWStart != NULL)
        sscanf(pGWStart + strlen("broadcast "), "%s", ip->gw);
    /* 查找mask */
    char *pMASKStart = strstr(tmp, "Mask:");
    if(pMASKStart != NULL)
        sscanf(pMASKStart + strlen("Mask:"), "%s", ip->mask);

    pclose(pp);
    /* PR_DEBUG("%s Get IP:%s", inf_name, ip->ip); */
    return OPRT_OK;
}

OPERATE_RET hwl_bnw_if_connect_internet(BOOL_T *status)
{
    NW_IP_S ipinfo = {0};
    OPERATE_RET op_ret = OPRT_OK;

    op_ret = wired_inf_get_ip(NET_DEV, &ipinfo);
    if(OPRT_OK != op_ret){
        *status = FALSE;
        return OPRT_OK;
    }

    if(0 == strcmp(ipinfo.ip,default_wired_ip)) {
        *status = FALSE;
        return OPRT_OK;
    }

    *status = TRUE;
    return OPRT_OK;
}

